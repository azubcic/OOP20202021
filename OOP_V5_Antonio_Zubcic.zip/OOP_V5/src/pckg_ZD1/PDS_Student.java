package pckg_ZD1;

public class PDS_Student extends Student {

    public PDS_Student(String name) {
        this.name = name;
        this.enrolmentDate = null;
        this.idStudent = cntStudents;
        Student.cntStudents++;
    }

    protected void completedStudy(int years) {
        if (years < 3) {
            System.out.println("Last year of the study not enrolled!.");
        } else {
            System.out.println(this.getClass().getSimpleName() + " is on the last year of the study programme!\n" +
                    "In this year student will complete study by finishing bachelor thesis...");
        }
    }

    @Override
    protected void infoStudent() {
        super.infoStudent();
        System.out.println("Student is on the: " + this.getClass().getSimpleName() + " - programme !");
    }
}
