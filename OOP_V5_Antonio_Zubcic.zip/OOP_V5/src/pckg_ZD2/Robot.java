package pckg_ZD2;

public class Robot implements CommonActions {
    private String name;
    private int id;
    private static int cnt = 0;

    public Robot() {
        this.name = null;
        this.id = cnt;
        Robot.cnt++;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIdRob(int id) {
        this.id = id;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    @Override
    public void walk(String str, int i) {
        System.out.println("This robot has walked in the direction: " + str + " " + i + " meters.");
    }

    @Override
    public void talk(String str) {
        System.out.println("This robot can't speak!");
    }

    @Override
    public void think(String str) {
        System.out.println("This robot is thinking about " + str + "\nStill thinking...");
    }

    @Override
    public int calculate(int i) {
        if (i <= 1) {
            return 1;
        }
        return i * calculate(i - 1);
    }

    @Override
    public String toString() {
        return "Robot{" +
                "name='" + name + '\'' +
                ", id=" + id +
                '}';
    }

    public void robotInfo() {
        System.out.println(toString());
    }
}
