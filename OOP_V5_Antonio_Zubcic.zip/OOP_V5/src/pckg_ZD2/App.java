package pckg_ZD2;

public class App {
    public static void main(String[] args) {
        Robot rob = new Robot();
        rob.setName("Roby");
        rob.setIdRob(45126);
        Person prs = new Person("Roberta");

        prs.think("Life");
        rob.think("Life");
        rob.robotInfo();
        prs.personInfo();
        prs.walk("North", 50);
        rob.walk("South", 123);
        rob.talk("Talk");
        prs.talk("Talk");
        System.out.println("********** Calculations **************");
        System.out.println(prs.calculate(9));
        System.out.println(rob.calculate(9));
    }
}
