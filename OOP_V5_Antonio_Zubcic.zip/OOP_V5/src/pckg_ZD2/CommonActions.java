package pckg_ZD2;

public interface CommonActions {

    void walk(String str, int i);

    void talk(String str);

    void think(String str);

    int calculate(int i);
}
