package pckg_ZD2;

import java.util.UUID;

public class Person implements CommonActions {
    private String name;
    private int id;
    private static int cnt = 0;

    public Person(String name) {
        this.name = name;
        this.id = cnt;
        Person.cnt++;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    @Override
    public void walk(String str, int i) {
        System.out.println("I'm a human, and you can't command to me!");
    }

    @Override
    public void talk(String str) {
        System.out.println("You want me to talk - ok: " + UUID.randomUUID().toString());
    }

    @Override
    public void think(String str) {
        System.out.println("Surely, humans are more capable of thinking then robots - aren't they?");
    }

    @Override
    public int calculate(int i) {
        int rez = i % 2;
        return rez;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", id=" + id +
                '}';
    }

    public void personInfo() {
        System.out.println(toString());
    }
}
