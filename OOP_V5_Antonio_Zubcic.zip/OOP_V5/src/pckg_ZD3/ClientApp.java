package pckg_ZD3;

import java.util.Scanner;

public class ClientApp {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Customer customer = new Customer("Duje");
        Customer customer1 = new Customer(("Matej"));
        Package pckg = new Package("WEB-11", customer,"Zadar", sc);
        pckg.putContent();
        pckg.calculateTotalPackagePrice();
        pckg.packageInfo();
        customer.customerInfo();
        customer1.customerInfo();
    }
}