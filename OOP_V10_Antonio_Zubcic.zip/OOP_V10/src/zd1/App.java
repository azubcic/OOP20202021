package zd1;

public class App {
    public static void main(String[] args) {
        MainFrame run = new MainFrame();
    }
}
