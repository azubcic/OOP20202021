package zd1;

import javax.swing.*;
import java.awt.*;

public class RightSide extends JPanel {
    private JTextArea jta;
    private JScrollPane jsp;

    public RightSide() {
        setLayout(new BorderLayout());
        initComps();
        add(jsp, BorderLayout.CENTER);
    }

    private void initComps() {
        jta = new JTextArea();
        jsp = new JScrollPane(jta, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    }

    public JTextArea getArea() {
        return jta;
    }


}
