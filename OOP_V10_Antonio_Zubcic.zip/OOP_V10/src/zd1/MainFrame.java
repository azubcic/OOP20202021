package zd1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private LeftSide left;
    private RightSide right;

    public MainFrame() {
        super("ZD 1");
        initComps();
        layoutAll();
        left.setPreferredSize(new Dimension(150, 450));
        setSize(550, 460);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        activateGUI();
    }

    private void initComps() {
        right = new RightSide();
        left = new LeftSide();
    }

    private void layoutAll() {
        setLayout(new BorderLayout());
        add(right, BorderLayout.CENTER);
        add(left, BorderLayout.WEST);
    }

    private void activateGUI() {
        left.getBttn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = left.getTextField().getText();
                left.getTextField().setText("");
                if (text.isEmpty()) {
                    JOptionPane.showMessageDialog(left, "Text field is empty!", "Warning text!", JOptionPane.WARNING_MESSAGE);
                } else {
                    right.getArea().append(text + "\n");
                    left.getResetButton().setEnabled(true);
                }
            }
        });
        if (right.getArea().getText().isEmpty()) left.getResetButton().setEnabled(false);
        left.getResetButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                right.getArea().setText("");
                left.getTextField().setText("");
                left.getResetButton().setEnabled(false);
            }
        });


    }
}




