package zd1;

import javax.swing.*;
import java.awt.*;

public class LeftSide extends JPanel {
    private JButton bttn;
    private JButton resetButton;
    private JLabel txt;
    private JTextField textField;

    public LeftSide() {
        initComps();
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,0,0,0);
        add(txt, gbc);
        gbc.gridy++;
        gbc.insets = new Insets(0,0,30,0);
        add(textField, gbc);
        gbc.insets = new Insets(100,0, 0 , 0);
        gbc.gridy++;
        add(bttn, gbc);
        gbc.insets = new Insets(30, 0, 0, 0);
        gbc.gridy++;
        add(resetButton, gbc);
    }

    private void initComps() {
        bttn = new JButton("Submit text");
        resetButton = new JButton("Reset");
        txt = new JLabel ("Text: ");
        textField = new JTextField(10);
    }

    public JButton getBttn() {
        return bttn;
    }

    public void setBttn(JButton bttn) {
        this.bttn = bttn;
    }

    public JButton getResetButton() {
        return resetButton;
    }

    public void setResetButton(JButton resetButton) {
        this.resetButton = resetButton;
    }

    public JLabel getTxt() {
        return txt;
    }

    public void setTxt(JLabel txt) {
        this.txt = txt;
    }

    public JTextField getTextField() {
        return textField;
    }

    public void setTextField(JTextField textField) {
        this.textField = textField;
    }
}
