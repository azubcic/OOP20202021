package zd2;


import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

public class DataPanel extends JPanel {
    private JTextArea txtArea;
    private JTextField txtField;
    private JScrollPane scp;
    private DecimalFormat df = new DecimalFormat("#.####");



    public DataPanel() {
        setLayout(new BorderLayout());
        createComps();
        add(scp, BorderLayout.CENTER);
        add(txtField, BorderLayout.SOUTH);
    }

    private void createComps() {
        txtArea = new JTextArea();
        txtField = new JTextField();
        scp = new JScrollPane(txtArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    }

    public void setData(double res) {
        String resStr = String.valueOf(df.format(res));
        txtField.setText(resStr);
    }

    public JTextArea getTxtArea() {
        return txtArea;
    }
}

