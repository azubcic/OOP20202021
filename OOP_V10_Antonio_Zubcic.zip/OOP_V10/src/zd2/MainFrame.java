package zd2;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

public class MainFrame extends JFrame {
    private FormPanel formPanel;
    private DataPanel dataPanel;

    public MainFrame() {
        super("Zadatak 2");
        createComp();
        setLayout(new BorderLayout());
        add(dataPanel, BorderLayout.CENTER);
        add(formPanel, BorderLayout.WEST);
        setSize(600, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        activateApp();
    }

    private void createComp() {
        formPanel = new FormPanel();
        dataPanel = new DataPanel();
    }

    public void activateApp() {
        formPanel.setFormListener(new FormListener() {
            @Override
            public void calculateFormEventOccured(FormEvent object) {
                double res = Calculation.calculate(object.getKreda(), object.getKamata(), object.getNacin(), object.getGodina());
                dataPanel.setData(res);

            }

            @Override
            public void listFormEventOccured(FormEvent object) {
                for (Calculation el : object.getCals()) {
                    dataPanel.getTxtArea().append("/////////// Calculation ////////////" + "\n");
                    dataPanel.getTxtArea().append("Visina kredita: " + el.getKreda() + "\n");
                    dataPanel.getTxtArea().append("Kamatna stopa: " + el.getKamata() + "\n");
                    dataPanel.getTxtArea().append("Godina otplate: " + el.getGodina() + "\n");
                    dataPanel.getTxtArea().append("Rata kredita: " + Calculation.calculate(el.getKreda(), el.getKamata(), el.getNacin(), el.getGodina()) + "\n");
                }
            }
        });
    }
}
