package zd2;


public class App {
    public static void main(String[] args) {
        MainFrame GUI = new MainFrame();
    }
}
