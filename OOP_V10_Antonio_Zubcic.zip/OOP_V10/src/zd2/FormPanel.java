package zd2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class FormPanel extends JPanel {
    private JTextField txtField;
    private JComboBox combo;
    private JRadioButton rbtnMnth;
    private JRadioButton rbtnQuart;
    private JButton btnOK;
    private JButton btnList;
    private DefaultComboBoxModel comboModel;
    private JTextField txtGodina;

    private FormListener listener;
    ButtonGroup group = new ButtonGroup();
    ArrayList<Calculation> calcs = new ArrayList<>();

    public FormPanel() {
        setLayout(new GridBagLayout());
        createComps();
        layoutComponents();
        setFormListener(listener);
        activateForm();

    }

    private void createComps() {
        txtField = new JTextField(8);
        txtGodina = new JTextField(8);
        rbtnMnth = new JRadioButton("Mjesecno placanje");
        rbtnQuart = new JRadioButton("Kvartalno placanje");
        rbtnMnth.setSelected(true);

        group.add(rbtnMnth);
        group.add(rbtnQuart);
        rbtnMnth.setActionCommand("12");
        rbtnQuart.setActionCommand("4");
        String[] arr = {"5%", "6%", "7%", "8%", "9%", "10%", "11%"};
        comboModel = new DefaultComboBoxModel(arr);
        combo = new JComboBox(comboModel);
        btnOK = new JButton("Prikazi");
        btnList = new JButton("Izracunaj");

    }

    public void layoutComponents() {

        GridBagConstraints gbc = new GridBagConstraints();

        // 1. Row
        gbc.weightx = 0.5;
        gbc.weighty = 1;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Visina kredita"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 5, 0, 5);
        gbc.anchor = GridBagConstraints.LINE_START;
        add(txtField, gbc);
        // 2. Row
        gbc.weightx = 0.5;
        gbc.weighty = 1;

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("GodinaOtplate"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 5, 0, 5);
        gbc.anchor = GridBagConstraints.LINE_START;
        add(txtGodina, gbc);

        // 3. Row
        gbc.weightx = 1;
        gbc.weighty = 0.2;

        gbc.gridx = 1;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(new JLabel("Kamatna stopa"), gbc);

        gbc.gridx = 1;
        gbc.gridy++;
        gbc.insets = new Insets(0, 5, 0, 5);
        gbc.anchor = GridBagConstraints.LINE_START;
        add(combo, gbc);

        // 4. Row
        gbc.weightx = 1;
        gbc.weighty = 0.1;

        gbc.gridx = 1;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(rbtnMnth, gbc);

        gbc.gridx = 1;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(rbtnQuart, gbc);
        // 5. Row
        gbc.weightx = 1;
        gbc.weighty = 2;

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.insets = new Insets(0, 10, 0, 0);
        gbc.anchor = GridBagConstraints.LINE_END;
        add(btnOK, gbc);


        gbc.gridx = 1;
        gbc.insets = new Insets(0, 5, 0, 12);
        gbc.anchor = GridBagConstraints.LINE_END;
        add(btnList, gbc);


    }

    public void setFormListener(FormListener list) {
        this.listener = list;

    }

    public void activateForm() {
        btnList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                float kreda = Float.parseFloat(txtField.getText());
                int godina = Integer.parseInt(txtGodina.getText());
                float kamata;
                switch (String.valueOf(combo.getSelectedItem())) {
                    case "5%":
                        kamata = 0.05f;
                        break;
                    case "6%":
                        kamata = 0.06f;
                        break;
                    case "7%":
                        kamata = 0.07f;
                        break;
                    case "8%":
                        kamata = 0.08f;
                        break;
                    case "9%":
                        kamata = 0.09f;
                        break;
                    case "10%":
                        kamata = 0.1f;
                        break;
                    case "11%":
                        kamata = 0.11f;
                        break;
                    default:
                        kamata = 0.05f;
                        break;
                }
                int nacin = Integer.parseInt(group.getSelection().getActionCommand());

                FormEvent obj = new FormEvent(this);
                obj.setKreda(kreda);
                obj.setGodina(godina);
                obj.setKamata(kamata);
                obj.setNacin(nacin);
                Calculation calc = new Calculation(kreda, kamata, nacin, godina);
                calcs.add(calc);

                if (listener != null) {
                    listener.calculateFormEventOccured(obj);
                }
            }
        });

        btnOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FormEvent obj = new FormEvent(this);
                obj.setCals(calcs);
                if (listener != null) {
                    listener.listFormEventOccured(obj);
                }
            }
        });
    }

}
