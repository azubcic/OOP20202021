package zd2;

public interface FormListener {
    void calculateFormEventOccured(FormEvent object);

    void listFormEventOccured(FormEvent object);
}
