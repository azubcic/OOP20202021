package zd3;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadLocalRandom;

public class App {

    public static void main(String[] args) {
        int capacity = 5;
        ArrayBlockingQueue<Integer> red = new ArrayBlockingQueue<Integer>(capacity);
        napuniRed(red, 9);
        simulacijaProcesiranjaReda(red, 11);

    }

    private static void napuniRed(ArrayBlockingQueue<Integer> red, int size) {
        int remaining = red.remainingCapacity();
        for (int i = 0; i < size; i++) {
            try {
                red.add(ThreadLocalRandom.current().nextInt(remaining * 10));
            } catch (IllegalStateException ise) {
                System.out.println("The Queue is full - can not add any additional elements! ");
            } finally {
                System.out.println(red);
            }
        }
    }

    private static boolean procesirajPrvi(ArrayBlockingQueue<Integer> red, int status) {
        if (status == 1) {
            Integer element = red.poll();
            System.out.println("Element " + element + " is in processing procedure! ");
            return true;
        }
        System.out.println("Waiting in line!!!");
        return false;
    }

    private static void dodajNoviElement(Integer element, ArrayBlockingQueue<Integer> red, boolean status) {
        if (status) {
            System.out.println("Adding new element in the queue!");
            System.out.println("Element " + element);
            red.add(element);
        } else {
            System.out.println("The queue is full - can not add additional elements! ");
        }
    }

    private static void simulacijaProcesiranjaReda(ArrayBlockingQueue<Integer> red, int ponavljanje) {
        for (int i = 0; i < ponavljanje; i++) {
            System.out.println("Red: " + red);
            int proc = ThreadLocalRandom.current().nextInt(2);
            boolean status = procesirajPrvi(red, proc);
            dodajNoviElement(ThreadLocalRandom.current().nextInt(300), red, status);
            System.out.println("<<<<<<<<<<<<<< Queue - after one step of simulation >>>>>>>>>>>>>>");
            System.out.println("Queue: " + red);
        }
    }
}
