package zd4;

import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class FileProc {

    public static void write2File(File file, int numLines) {

        try (FileWriter fw = new FileWriter(file, true)) {
            BufferedWriter bw = new BufferedWriter(fw);
            for (int i = 0; i < numLines; i++) {
                int randi = ThreadLocalRandom.current().nextInt(numLines * 0);
                bw.write(i + ": file - " + Integer.toHexString(file.hashCode() + randi));
                bw.newLine();
            }
            bw.close();

        } catch (IOException ioe) {
            System.out.println("File not found - " + file.getName());
        } finally {
            System.out.println("Writing finished!");
        }
    }

    public static List<String> listFromFile(File file, Scanner sc) {
        List<String> slst = new ArrayList<>();
        System.out.println("Reading from file " + file.getName());
        try {
            sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                System.out.println("Line: " + line);
                slst.add(line);
            }
            return slst;
        } catch (FileNotFoundException e) {
            System.out.println("Can not read from the file - " + file.getName() + "!!!");
            System.out.println("Returning an empty list!");
            return slst;
        }
    }

    public static boolean readFileWScanner(Path filePath, Scanner sc) {
        System.out.println("Reading from file: " + filePath.toString());
        System.out.println("Reading with: " + sc.getClass().getSimpleName());
        try {
            sc = new Scanner(filePath);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                System.out.println(line);
            }
            return false;
        } catch (IOException e) {
            System.out.println("Can not read from the file => " + filePath);
        }
        return true;
    }

    public static boolean readFileWBufferedReader(Path filePath) {
        try (FileReader fr = new FileReader(String.valueOf(filePath))) {
            BufferedReader br = new BufferedReader(fr);
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
            br.close();
            return false;
        } catch (IOException e) {
            System.out.println("Can not read from the file => " + filePath);
            return true;
        }
    }
}
