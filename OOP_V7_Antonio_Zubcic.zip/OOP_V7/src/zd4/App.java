package zd4;

import java.io.File;
import java.nio.file.Path;
import java.util.Scanner;

public class App {

    private static Scanner sc;

    public static void main(String[] args) {
        File file = new File("Data.txt");
        String filePath = file.getPath();
        System.out.println(filePath);
        fileReadingTest();
    }

    private static void fileReadingTest() {
        boolean status = true;
        while (status) {
            System.out.println("Enter the path to the file: ");
            sc = new Scanner(System.in);
            String path = sc.nextLine();
            Path filePath = Path.of(path);
            System.out.println("Chose file reading procedure... \n");
            System.out.println("For scanner reading - chose 1!");
            System.out.println("For bufferreader - chose 2!");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    status = FileProc.readFileWScanner(filePath, sc);
                    System.out.println("Status after the reading with the Scanner: " + status);
                    break;
                case 2:
                    status = FileProc.readFileWBufferedReader(filePath);
                    System.out.println("Status after the reading with the Buffered Reader: " + status);
                    break;
                default:
                    System.out.println("Something went wrong - 1 or 2 expected!");
                    status = false;
            }
            System.out.println("Do you want to read some other file - 1 for YES!");
            int cont = sc.nextInt();
            if (cont == 1) {
                status = true;
            } else {
                status = false;
            }
        }
    }
}
