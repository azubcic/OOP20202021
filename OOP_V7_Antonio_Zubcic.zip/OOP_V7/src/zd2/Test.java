package zd2;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Test {

    public static void main(String[] args) {
        List<Integer> generated = Code.genArray(10, 0, 1000);
        System.out.println("Generated new List: " + generated);
        Collections.sort(generated);
        System.out.println("Sorted List: " + generated);
        Collections.sort(generated, new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                    return Integer.compare(b, a);
            }
        });
        System.out.println("Reverse sort: " + generated);
    }

}
