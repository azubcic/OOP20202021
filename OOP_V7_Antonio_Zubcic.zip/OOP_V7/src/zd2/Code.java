package zd2;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Code {

    public static List<Integer> genArray(int velicina, int min, int max) {
        List<Integer> generated = new ArrayList<>();
        for (int i = 0; i < velicina; i++) {
            generated.add(ThreadLocalRandom.current().nextInt(min, max));
        }
        return generated;
    }
}
