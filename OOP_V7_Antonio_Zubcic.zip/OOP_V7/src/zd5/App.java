package zd5;

import java.util.Iterator;
import java.util.LinkedList;

import static java.util.Arrays.asList;

public class App {

    public static void main(String[] args) {
        LinkedList<String> ll = new LinkedList<String>(asList("Car", "Helicopter", "Electric bike", "Truck", "Motorcycle", "Carriage"));
        System.out.println("= meth printList =");
        printList(ll);
        System.out.println("= meth iteratorPrintList =");
        iteratorPrintList(ll);
        System.out.println("= List from insertVeh meth =");
        ListProcessing.insertVeh(ll, "PLANE");
    }
     public static void printList(LinkedList<String> lista) {
        for (String s : lista) {
            System.out.println(s);
        }
    }

    private static void iteratorPrintList(LinkedList<String> lista) {
        Iterator<String> it = lista.iterator();
        while (it.hasNext()) {
            String el = it.next();
            if (el.equals("Carriage")) {
                System.out.println(el);
                lista.remove(el);
                System.out.println("[] Carriage has been found in the list and removed!");
            }
        }
        System.out.println("= After while loop =");
        System.out.println(lista);
    }

}
