package zd5;

import java.util.LinkedList;
import java.util.ListIterator;

public class ListProcessing {

    public static void insertVeh(LinkedList<String> lista, String insertVehicle) {
        ListIterator<String> it = lista.listIterator();
        while (it.hasNext()) {
            String el = it.next();
            if (el.equals("Electric bike")) {
                it.add(insertVehicle);
            }
        }
        System.out.println("List after insertion: ");
        App.printList(lista);
    }
}
