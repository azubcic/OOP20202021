package zd1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class App {

    public static void main(String[] args) {

        ArrayList<String> rijeci = new ArrayList<>(Arrays.asList("auto", "svemirski brod", "avion", "helikopter", "jedrilica", "gliser", "romobil", "bicikla"));
        System.out.println("======== Pocetna lista ========");
        System.out.println(rijeci);
        System.out.println("======== Sortirana lista ========");
        StringLengthComparator scomp = new StringLengthComparator();
        Collections.sort(rijeci, scomp);
        System.out.println(rijeci);
        System.out.println("======== REV SORT LEN =========");
        StringLengthComparator rstr = (StringLengthComparator) scomp.reversed();
        Collections.sort(rijeci, rstr);
        System.out.println(rijeci);
    }
}
