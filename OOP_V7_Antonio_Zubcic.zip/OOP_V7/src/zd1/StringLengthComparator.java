package zd1;

import java.util.Comparator;

public class StringLengthComparator implements Comparator<String> {


    @Override
    public int compare(String s1, String s2) {
        return Integer.compare(s1.length(), s2.length());
    }

    @Override
    public Comparator<String> reversed() {

        return new StringLengthComparator() {
            @Override
            public int compare(String s1, String s2) {
                return super.compare(s2, s1);
            }
        };

    }


}
