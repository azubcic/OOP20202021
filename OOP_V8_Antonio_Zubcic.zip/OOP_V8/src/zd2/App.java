package zd2;

import java.util.Scanner;
import java.util.InputMismatchException;

public class App {

    public static void main(String[] args) {
        unesiInteger();
    }

    public static void unesiInteger() {
        Scanner sc = new Scanner(System.in);
        boolean nastavi = true;
        while (nastavi) {
            try {
                System.out.println("Molimo unesite neki cijeli broj: ");
                int userInput = sc.nextInt();
                nastavi = false;
                System.out.println("Broj koji ste unjeli je: " + userInput);
            } catch (InputMismatchException ime) {
                System.out.println("Ups... nešto je pošlo po zlu! Želite li pokušati ponovno?");
                System.out.println("[D za DA] / [bilo što za NE]");
                sc.next();
                String answer = sc.next().toLowerCase();
                if (!answer.equals("d")) {
                    System.out.println("OK, prekidam program!");
                    sc.close();
                    nastavi = false;
                }
            }
        }
    }
}
