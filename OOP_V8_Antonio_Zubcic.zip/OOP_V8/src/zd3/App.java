package zd3;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class App {

    public static void main(String[] args) {
        int[] newArray = genArray(10);
        System.out.println("Generirana lista: " + Arrays.toString(newArray));
        try {
            System.out.println(newArray[newArray.length]);
        } catch (IndexOutOfBoundsException ioob) {
            StackTraceElement[] ste = ioob.getStackTrace();
            System.out.println("Exception: " + ioob.getClass().getCanonicalName() + " in: " + ste[0]);
        } finally {
            System.out.println("Be careful => array length is: " + newArray.length);
        }
    }

    private static int[] genArray(int arraySize) {
        int[] arr = new int[arraySize];
        int cnt = 0;
        while (cnt != arraySize) {
            arr[cnt] = ThreadLocalRandom.current().nextInt(100);
            cnt++;
        } return arr;
    }
}
