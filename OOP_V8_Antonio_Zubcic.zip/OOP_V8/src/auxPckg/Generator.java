package auxPckg;

import java.util.concurrent.ThreadLocalRandom;

public class Generator {

    private static final int LOW = 1;
    private static final int UPP = 120;

    public Generator(){}

    //generates age to guess
    public static int genAge2Guess() {
        int age;
        age = ThreadLocalRandom.current().nextInt(LOW, UPP);
        return age;
    }
}
