package auxPckg;

public class UserInpts {

    private int lwr;
    private int uppr;
    private int guess;
    private boolean status;

    public UserInpts(){}

    public void setInputs(int low, int up, int userguess) {
        this.lwr = low;
        this.uppr = up;
        this.guess = userguess;
    }

    public int getLwr() {
        return lwr;
    }

    public void setLwr(int lwr) {
        this.lwr = lwr;
    }

    public int getUppr() {
        return uppr;
    }

    public void setUppr(int uppr) {
        this.uppr = uppr;
    }

    public int getGuess() {
        return guess;
    }

    public void setGuess(int guess) {
        this.guess = guess;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "UserInpts{" +
                "lwr=" + lwr +
                ", uppr=" + uppr +
                ", guess=" + guess +
                ", status=" + status +
                '}';
    }
}

