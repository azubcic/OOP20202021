package auxPckg;

public class UsrInputException extends Exception {

    private int lwr;
    private int uppr;
    private int plGuess; // player guess
    private String msg; // exception message

    public UsrInputException(String msg) {
        super(msg);
        this.msg = msg;
    }

//    public void setLwr(int lwr) {
//        try {
//            this.lwr = lwr;
//        } catch (UsrInputException uie) {
//            throw new UsrInputException("You entered: <" + lwr + "> for the lower age bound!!!");
//        }
//    }
//
//    public void setUppr(int uppr) {
//        this.uppr = uppr;
//        System.out.println("You entered: <" + uppr + "> for the upper age bound!!!");
//    }
//
//    public void setGuess(int plGuess) {
//        this.plGuess = plGuess;
//    }
}
