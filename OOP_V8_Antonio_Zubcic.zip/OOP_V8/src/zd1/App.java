package zd1;

public class App {

    public static void main(String[] args) {

        String fileName = "randTekst.txt";
        System.out.println("******************** Reading with Scanner *************************");
        FileHandling.readFileScanner(fileName);
        System.out.println("\n******************** Reading with Buffrdr *************************");
        FileHandling.readFileBufferedReader(fileName);
        System.out.println("\n******************** Writing to file *************************");
        FileHandling.write2File("nekiNoviTekst.txt");
        System.out.println("\n******************** Ask user for file name *************************");
        FileHandling.askUser4File();
    }
}
