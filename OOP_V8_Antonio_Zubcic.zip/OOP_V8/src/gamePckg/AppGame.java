package gamePckg;

public class AppGame {

    public AppGame() {}

    public static void main(String[] args) {
        Game.runGame();

    }
}
