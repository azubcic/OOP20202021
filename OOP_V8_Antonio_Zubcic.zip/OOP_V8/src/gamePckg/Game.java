package gamePckg;

import auxPckg.Generator;
import auxPckg.UserInpts;
import auxPckg.UsrInputException;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Game {

    private static int age2Guess;
    private static int cnt;
    private static boolean gameCont;
    private static Scanner sc;

    public Game() {
    }

    public static void runGame() {
        gameCont = true;
        age2Guess = Generator.genAge2Guess();
        System.out.println("WELCOME\nThis is an age guessing game!");
        System.out.println("Rules are simple:\nYou have to enter an integer value for your guess from 1 to 120.\nNow when you know everything let's start playing! ;)");
        sc = new Scanner(System.in);
        while (gameCont) {
            cnt++;
            UserInpts userInput = userInputs();
            if (!userInput.isStatus()) {
                gameCont = false;
            } else if (userInput.getGuess() > 0 && userInput.getLwr() > 0 && userInput.getUppr() > 0) {
                gameCont = guessStatus(userInput, cnt);
            } else {
                gameCont = true;
            }
        }
    }

    //     store lower and upper bound + players' guess
    private static UserInpts userInputs() {
        int in_val;
        UserInpts usrInpts = new UserInpts();
        try {
            System.out.println("[] Please enter your guess:");
            in_val = sc.nextInt();
            isInptNegative(in_val);
            usrInpts.setGuess(in_val);
            System.out.println("Please enter your guess for the lower boundary: ");
            in_val = sc.nextInt();
            isInptNegative(in_val);
            int testLower = in_val;
            System.out.println("Please enter your guess for the upper boundary: ");
            in_val = sc.nextInt();
            isInptNegative(in_val);
            int testUpper = in_val;
            // test for bad input
            if (testLower >= in_val) {
                throw new UsrInputException("The boundary for lower must not be greater or same as upper boundary!");
            }
            // if everything is ok
            usrInpts.setLwr(testLower);
            usrInpts.setUppr(testUpper);
            usrInpts.setStatus(true);
        } catch (InputMismatchException ime) {
            sc.next();
            System.out.println("Your guess has to be an integer value!");
            gameCont = contGame();
            usrInpts.setStatus(gameCont);
            cnt--;
        } catch (UsrInputException uie) {
            sc.next();
            System.out.println(uie.getMessage());
            gameCont = contGame();
            usrInpts.setStatus(gameCont);
            cnt--;
        }
        return usrInpts;

    }

    //     Exception msg → negative not allowed
    private static void isInptNegative(int val) throws UsrInputException {
        if (val < 0) {
            throw new UsrInputException("Negative values are not allowed!");
        }
    }

    //     asking player to continue?
    private static boolean contGame() {
        boolean contGame = false;
        System.out.println("Do you want to continue playing?\n[1 for yes] / [Any other for no]");
        try {
            int val = sc.nextInt();
            if (val == 1) {
                contGame = true;
            } else {
                System.out.println("Thanks for playing! Hope to see You again! ");
                sc.close();
            }
        } catch (InputMismatchException ime) {
            sc.next();
            System.out.println("Thanks for playing! Hope to see You again! ");
            contGame = false;
            sc.close();
        } return contGame;

    }

    //     guessing status with bounds checking
    private static boolean guessStatus(UserInpts usInpt, int cnt) {
        if (usInpt.getGuess() == age2Guess) {
            System.out.println("Congratulations, You have won!\nYou guessed: " + age2Guess + " = " + usInpt.getGuess());
            System.out.println("You had " + cnt + " attempts before winning!\nThank You for playing!");
            sc.close();
            gameCont = false;
        } else if (age2Guess <= usInpt.getLwr()) {
            System.out.println("Value you are trying to guess is less or equal to the lower bound! " + usInpt.getLwr() + " ;)");
            gameCont = contGame();
        } else if (age2Guess >= usInpt.getLwr()) {
            System.out.println("Value you are trying to guess is greater or equal to the upper bound! " + usInpt.getUppr() + " ;)");
            gameCont = contGame();
        } else {
            System.out.println(usInpt.getLwr() + " <= value <= " + usInpt.getUppr());
            gameCont = contGame();
        }
        return gameCont;
    }
}
