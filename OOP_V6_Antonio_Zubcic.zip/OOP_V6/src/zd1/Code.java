package zd1;

import java.util.LinkedList;

public class Code {

    public static void switchElement (LinkedList<String> lista, int index, String rijec) {
        lista.remove(index);
        lista.set(index, rijec);
    }

    public static void upgradeSwitchElement (LinkedList<String> lista, int index, String rijec) {
        String save = lista.get(index);
        lista.remove(index);
        lista.set(index, rijec);
        System.out.println("The element that was deleted: " + save);
    }


}
