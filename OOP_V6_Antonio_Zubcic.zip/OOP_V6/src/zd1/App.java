package zd1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

public class App {

    public static void main(String[] args) {
        ArrayList<String> lista = new ArrayList<>(Arrays.asList("Apple", "Samsung", "Huawei", "OnePlus", "Sony"));
        System.out.println("ArrayList: " + lista);
        LinkedList<String> linkedlista = new LinkedList<>(lista);
        System.out.println("----------------------------------------------------");
        System.out.println("LinkedList: " + lista);
        linkedlista.addLast("Acer");
        linkedlista.addFirst("CAT");
        linkedlista.addLast("ROG");
        System.out.println("==================== FOR EACH ======================");
        for (String e : linkedlista) {
            System.out.println(e);
        }
        System.out.println("============= Nakon switchElement metode ============");
        Code.switchElement(linkedlista, 5, "Bio Acer");
        System.out.println(linkedlista);
        System.out.println("============= upgradeSwitchElement method ===========");
        Code.upgradeSwitchElement(linkedlista, 0, "upgrade");
        System.out.println(linkedlista);

    }

}
