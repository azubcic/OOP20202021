package zd2;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class App {

    public static void ispisMapa(Map<Integer, String> ulaz){
        for (int id : ulaz.keySet()) {
            System.out.println("id = " + id + ", Name: " + ulaz.get(id));
        }
    }

    public static void main(String[] args) {

        HashMap<Integer, String> baza = new HashMap<>();
        baza.put(21, "Stipe");
        baza.put(159, "Divna");
        baza.put(985, "Etna");
        baza.put(455, "Petar");
        baza.put(5788, "Vlatka");
        System.out.println("=HM=");
        for (int id : baza.keySet()) {
            System.out.println("id = " + id + ", Name: " + baza.get(id));
        }
        TreeMap<Integer, String> tm = new TreeMap<>(baza);
        System.out.println("=TM=");
        ispisMapa(tm);
        // uocavamo da je tm sortiran po keyu
    }
}
