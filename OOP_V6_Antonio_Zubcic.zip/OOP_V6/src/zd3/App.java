package zd3;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class App {

    public static void popuniSet(Set<String> nekiSet) {
        nekiSet.add("Apple");
        nekiSet.add("Samsung");
        nekiSet.add("Huawei");
        nekiSet.add("Xiaomi");
        nekiSet.add("OnePlus");
        System.out.println("Set has been filled!");
        System.out.println(nekiSet);
    }

    // ostavio sam proslu metodu
    public static void imaLiNemaGa(Set<String> nekiSet) {
        if (nekiSet.contains("Nema ga") || nekiSet.contains("nema ga")) {
            System.out.println("[] Element {Nema ga} postoji u setu!");
        } else {
            System.out.println("[] Element {Nema ga} ne postoji u setu!");
            nekiSet.add("Nema ga");
            System.out.println("[] Dodan element {Nema ga} u set!");
        }
    }

    //modificirani imaLi
    public static boolean imaLiElemeta(Set<String> nekiSet, String element){
        if (nekiSet.contains(element)) {
            return true;
        } else {
            return false;
        }
    }

    public static void removeElement(Set<String> nekiSet, String element) {
        if (imaLiElemeta(nekiSet, element) == true) {
            System.out.println("[] Element " + element + " uklonjen je iz skupa");
            nekiSet.remove(element);
        } else {
            System.out.println("[] Element se ne nalazi u skupu, stoga nije ni uklonjen!");
        }
    }

    public static void ispisSkupa(Set<String> nekiSet) {
        for (String element : nekiSet) {
            System.out.println(element);
        }
    }

    public static void main(String[] args) {
        HashSet<String> hsString = new HashSet<String>();
        popuniSet(hsString);
        LinkedHashSet<String> lhsString = new LinkedHashSet<String>(hsString);
        TreeSet<String> tsString = new TreeSet<String>(hsString);
        System.out.println("================= HS =================");
        ispisSkupa(hsString);
        System.out.println("================= LHS =================");
        ispisSkupa(lhsString);
        System.out.println("================= Ts =================");
        imaLiNemaGa(tsString);
        System.out.println("=======================================");
        ispisSkupa(tsString);
        System.out.println("============= 2. test metode nema ga ==============");
        imaLiNemaGa(tsString);
        ispisSkupa(tsString);
        System.out.println("============= TEST removeElement ==============");
        removeElement(tsString, "Huawei");
        ispisSkupa(tsString);

    }
}
