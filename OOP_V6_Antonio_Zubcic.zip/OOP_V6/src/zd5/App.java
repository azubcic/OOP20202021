package zd5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class App {

    public static void main(String[] args) {

        ArrayList<String> rijeci = new ArrayList<>(Arrays.asList("auto", "svemirski brod", "avion", "helikopter", "jedrilica", "gliser", "romobil", "bicikla"));
        System.out.println("======== Pocetna lista ========");
        System.out.println(rijeci);
        System.out.println("======== Sortirana lista ========");
        Collections.sort(rijeci);
        System.out.println(rijeci);
        System.out.println("======== TEST SORT LEN =========");
        Collections.sort(rijeci, new LengthStrComparator());
        for (String st : rijeci) {
            System.out.println(st);

        }
    }
}
