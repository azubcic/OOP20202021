package zd4;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;

public class App {

    public static void main(String[] args) {

        Robot flyingRobot = new Robot(1, "Flying Robot");
        Robot cleaningRobot = new Robot(2, "Cleaning Robot");
        Robot thinkingRobot = new Robot(3, "Thinking Robot");
        Robot humorousRobot = new Robot(4, "Humorous Robot");
        Robot friendlyRobot = new Robot(5, "Friendly Robot");
        Robot weirdRobot = new Robot(6, "Weird Robot");

        LinkedHashMap<Robot, Integer> robotiLHM = new LinkedHashMap<>();
        robotiLHM.put(flyingRobot, 456);
        robotiLHM.put(cleaningRobot, 352);
        robotiLHM.put(thinkingRobot, 124);
        robotiLHM.put(humorousRobot, 251);
        robotiLHM.put(friendlyRobot, 865);
        robotiLHM.put(weirdRobot, 242);
        robotiLHM.put(friendlyRobot, 865);
        LinkedHashSet<Robot> robotiLHS = new LinkedHashSet<>();
        robotiLHS.add(flyingRobot);
        robotiLHS.add(cleaningRobot);
        robotiLHS.add(thinkingRobot);
        robotiLHS.add(humorousRobot);
        robotiLHS.add(friendlyRobot);
        robotiLHS.add(weirdRobot);
        robotiLHS.add(friendlyRobot);
        System.out.println("=================== LHM ======================");
        for (Robot element : robotiLHM.keySet()) {
            System.out.println(element.toString() + " : " + robotiLHM.get(element));
        }
        System.out.println("=================== LHS ======================");
        for (Robot element : robotiLHS) {
            System.out.println(element.toString());
        }
    }
}