package zd3;

import java.io.Serializable;
import java.util.ArrayList;

public class SpaceScientist implements Serializable {

    private String name;
    private int id;
    private String specialization;
    private ArrayList<String> equipment;
    private transient Species spec;

    public SpaceScientist(String name, int id, String specialization, ArrayList<String> equipment, Species spec) {
        this.name = name;
        this.id = id;
        this.specialization = specialization;
        this.equipment = equipment;
        this.spec = spec;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public ArrayList<String> getEquipment() {
        return equipment;
    }

    public void setEquipment(ArrayList<String> equipment) {
        this.equipment = equipment;
    }

    public Species getSpec() {
        return spec;
    }

    public void setSpec(Species spec) {
        this.spec = spec;
    }

    @Override
    public String toString() {
        return "SpaceScientist [" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", specialization='" + specialization + '\'' +
                ", equipment=" + equipment +
                ", spec=" + spec +
                ']';
    }
}
