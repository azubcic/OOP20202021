package zd3;

public class Species {

    public final String name;
    public final String description;

    public Species(String name, String description) {
        this.name = name;
        this.description = description;
    }

    @Override
    public String toString() {
        return "Species [" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ']';
    }
}
