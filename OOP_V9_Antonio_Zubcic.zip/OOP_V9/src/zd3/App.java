package zd3;

import zd1i2.Gunslinger;

import java.util.ArrayList;
import java.util.List;

public class App {

    public static void main(String[] args) {
        Species zeltron = new Species("Zeltrons", "Hedonistic creatures with warm red skin tones. ");
        ArrayList<String> equipment = new ArrayList<>();
        equipment.add("Pickaxe");
        equipment.add("Radio-Communication device");
        equipment.add("Repair tool");
        equipment.add("Laser Gun");
        equipment.add("Secret tool - Romald");
        SpaceScientist zeltronScientist = new SpaceScientist("Grovrom", 423,"Technology", equipment, zeltron);

        Species zabraks = new Species("Zabraks", "Near huaman species with horns and facial tattoos. ");
        ArrayList<String> equipment2 = new ArrayList<>();
        equipment2.add("Lightsaber");
        equipment2.add("Stronger Laser Gun");
        equipment2.add("Microscope");
        equipment2.add("Radio-Communication device");
        equipment2.add("Secret weapon - RayGun");
        equipment2.add("Secret: Dark Lightsaber");
        SpaceScientist zabraksScientist = new SpaceScientist("Uevuk", 25,"Weapon development", equipment2, zabraks);

        List<SpaceScientist> listOfSpecies = new ArrayList<>();
        listOfSpecies.add(zeltronScientist);
        listOfSpecies.add(zabraksScientist);

        ObjHandleForScientists.ser2File("./.bin2", listOfSpecies);
        System.out.println("Saved new objects to file!");
        readObjects(listOfSpecies);

        System.out.println("\nLoaded objects: ");
        List<Gunslinger> listOfGunslinger = ObjHandleForScientists.readSerialized("./.bin2,");
        readObjects(listOfGunslinger);

        System.out.println("\nWriting data to .csv");
        readObjects(listOfSpecies);
        ObjHandleForScientists.wwriteDatatoTxt(".\sSpaceScientists.csv", listOfSpecies);

        System.out.println("\nRead from csv:");
        List<SpaceScientist> lista = ObjHandleForScientists.readObjFromCsv("./SpaceScientists.csv");
        readObjects(lista);
    }


    private static <T> void readObjects(List<T> lst) {
        lst.forEach(o -> System.out.println(o.toString()));
    }
}
