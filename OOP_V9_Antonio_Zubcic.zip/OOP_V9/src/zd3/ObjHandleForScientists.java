package zd3;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ObjHandleForScientists {

    public static <T> void ser2File(String filePath, List<T> objs) {
        File file = new File(filePath);
        try (
                FileOutputStream fout = new FileOutputStream(file);
                ObjectOutputStream oout = new ObjectOutputStream(fout);
        ) {
            oout.writeObject(objs);
        } catch (FileNotFoundException e) {
            System.out.println("File " + filePath + " does not exist");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public static <T> List<T> readSerialized(String filePath) {
        File file = new File(filePath);
        List<T> objs = new ArrayList<>();
        try (FileInputStream fin = new FileInputStream(file);
             ObjectInputStream oin = new ObjectInputStream(fin);
        ) {

            T temp = (T) oin.readObject();
            objs.addAll((Collection<? extends T>) temp);
        } catch (FileNotFoundException e) {
            System.out.println("File " + filePath + " does not exist");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return objs;
    }

    public static void wwriteDatatoTxt(String filePath, List<SpaceScientist> objs) {
        File file = new File(filePath);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file));) {
            for (SpaceScientist obj : objs) {
                String data = "";
                data += obj.getName();
                data += ",";
                data += obj.getId();
                data += ",";
                data += obj.getSpecialization();
                data += ",";
                for (String equipment : obj.getEquipment()) {
                    data += equipment += ":";
                }
                data += "/";
                data += obj.getSpec().name;
                data += ",";
                data += obj.getSpec().description;
                writer.write(data);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<SpaceScientist> readObjFromCsv(String filePath) {
        File file = new File(filePath);
        List<SpaceScientist> recon = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(file));) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split("/");
                String[] fields = data[0].split(",");
                String[] species = data[1].split(",");
                String name = fields[0];
                int id = Integer.parseInt(fields[1]);
                String specialization = fields[2];
                String[] equipmentElements = fields[3].replace("[", "").replace("]", "").split(":");
                ArrayList<String> equipment = new ArrayList<>();
                for (String equip : equipmentElements) {
                    equipment.add(equip);
                }
                String specName = species[0];
                String specDesc = species[1];
                Species spec = new Species(specName, specDesc);
                SpaceScientist scientist = new SpaceScientist(name, id, specialization, equipment, spec);
                recon.add(scientist);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File " + filePath + " does not exist");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return recon;
    }

}

