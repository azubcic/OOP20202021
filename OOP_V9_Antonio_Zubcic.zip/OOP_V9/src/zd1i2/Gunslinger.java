package zd1i2;

import java.time.LocalDate;
import java.util.concurrent.ThreadLocalRandom;

public class Gunslinger {

    private String name;
    private LocalDate dob;
    private int duels;
    private String strongHands;
    private boolean twoGuns;

    public Gunslinger(String name) {
        this.name = name;
    }

    public Gunslinger(String name, String hnd, boolean twoG, int ccaYr) {
        this.name = name;
        this.strongHands = hnd;
        this.twoGuns = twoG;
        this.dob = genDOB(ccaYr);
        this.duels = genDuelsWon();
    }

    private LocalDate genDOB(int ccaYr) {
        LocalDate dob;
        LocalDate startDate = LocalDate.of(ccaYr, 1,1 );
        long start = startDate.toEpochDay();
        System.out.println(start);
        int rndYr = ThreadLocalRandom.current().nextInt(ccaYr+25, ccaYr+100);
        LocalDate endDate = LocalDate.of(rndYr, 1, 1);
        long end = endDate.toEpochDay();
        long dobs = ThreadLocalRandom.current().longs(start, end).findAny().getAsLong();
        dob = LocalDate.ofEpochDay(dobs);
        return dob;
    }

    private int genDuelsWon() {
        return ThreadLocalRandom.current().nextInt(10,100);
    }

    public String getName() {
        return name;
    }

    public LocalDate getDob() {
        return dob;
    }

    public int getDuels() {
        return duels;
    }

    public String getStrongHands() {
        return strongHands;
    }

    public boolean isTwoGuns() {
        return twoGuns;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public void setDuels(int duels) {
        this.duels = duels;
    }

    public void setStrongHands(String strongHands) {
        this.strongHands = strongHands;
    }

    public void setTwoGuns(boolean twoGuns) {
        this.twoGuns = twoGuns;
    }
}
