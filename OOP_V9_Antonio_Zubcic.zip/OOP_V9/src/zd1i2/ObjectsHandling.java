package zd1i2;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class ObjectsHandling {

    public static <T> void saveObj2File(String fullPath, List<T> objcts) {

        File file = new File(fullPath);

        try (FileOutputStream fos = new FileOutputStream(file);
             ObjectOutputStream oos = new ObjectOutputStream(fos);
        ) {
            oos.writeObject(objcts);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public static <T> List<T> read4File(String fullPath) {

        File file = new File(fullPath);
        List<T> objects = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis);
        ) {
            T ob = (T) ois.readObject();
            System.out.println(ob.toString());
            System.out.println(ob.getClass().getCanonicalName());
            objects.addAll((Collection<? extends T>) ob);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return objects;
    }

    public static void writeIntoTxt(String filePath, ArrayList<Gunslinger> dta) {

        File file = new File(filePath);
        try (FileWriter fw = new FileWriter(filePath);
            BufferedWriter buff = new BufferedWriter(fw);
        ){
            for (int i = 0; i < dta.size(); i++) {
                buff.flush();
                buff.write(dta.get(i).getName());
                buff.write(", ");
                int duelsWon = dta.get(i).getDuels();
                buff.write(Integer.toString(duelsWon));
                buff.write(", ");
                buff.write(dta.get(i).getStrongHands());
                buff.write(", ");
                boolean two = dta.get(i).isTwoGuns();
                buff.write(Boolean.toString(two));
                buff.write(", ");
                DateTimeFormatter dobFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                String formatedDOB = dta.get(i).getDob().format(dobFormatter);
                buff.write(formatedDOB);
                buff.newLine();
            }
            System.out.println("Writing to file finished to: " + file.getPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<String[]> read4CSVFile(String fullPath) {
        List<String[]> data = new ArrayList<String[]>();
        File file = new File(fullPath);
        String[] rowData;
        String lnRow;

        try (FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
        ){
            while ((lnRow = br.readLine()) != null) {
                rowData = lnRow.split("\\s*, \\s*");
                data.add(rowData);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    public static void listAllData4File(List<String[]> data) {
        for (String[] strings : data) {
            System.out.println(Arrays.toString(strings));
        }
    }

    public static List<Gunslinger> recreateObj4TxtFile(List<String[]> data) {

        List<Gunslinger> guns = new ArrayList<>();

        data.forEach(row -> {
            Gunslinger gns;
            int cnt = 0;
            String name = row[cnt];
            System.out.println(name);
            cnt++;
            Integer duels = Integer.parseInt(row[cnt]);
            cnt++;
            String domHand = row[cnt];
            cnt++;
            boolean twoGuns = Boolean.parseBoolean(row[cnt]);
            cnt++;
            DateTimeFormatter dobFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate dob = LocalDate.parse(row[cnt], dobFormatter);
            gns = new Gunslinger(name);
            gns.setDob(dob);
            gns.setDuels(duels);
            gns.setStrongHands(domHand);
            gns.setTwoGuns(twoGuns);
            guns.add(gns);
        });
        return guns;
    }
}
