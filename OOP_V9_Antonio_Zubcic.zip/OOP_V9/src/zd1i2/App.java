package zd1i2;

import java.util.ArrayList;
import java.util.List;


public class App {

    public static void main(String[] args) throws ClassNotFoundException {

        Gunslinger gn1 = new Gunslinger("Wyatt Earp", "right", true, 1845);
        Gunslinger gn2 = new Gunslinger("Billy the Kid", "left", false, 1830);
        Gunslinger gn3 = new Gunslinger("Wild Bill Hickok", "both", true, 1820);
        List<Gunslinger> gunsSave = new ArrayList<>();
        gunsSave.add(gn1);
        gunsSave.add(gn2);
        gunsSave.add(gn3);
        List<Gunslinger> gunsRead;
        List<String[]> gunsCSV;
        List<Gunslinger> reconstGuns;

        ObjectsHandling.saveObj2File("gunFighters.bin", gunsSave);

        gunsRead = ObjectsHandling.read4File("gunFighters.bin");
        readObjects(gunsRead);
        // Now as csv file
        ObjectsHandling.writeIntoTxt("gunfighters.csv", (ArrayList<Gunslinger>) gunsSave);
        gunsCSV = ObjectsHandling.read4CSVFile("gunfighters.csv");
        System.out.println("\n");
        ObjectsHandling.listAllData4File(gunsCSV);
        reconstGuns = ObjectsHandling.recreateObj4TxtFile(gunsCSV);
        // List all reconstructed objects
        System.out.println("************ Reconstruction from csv file -> all objects **************");
        readObjects(reconstGuns);

    }

    private static <T> void readObjects(List<T> lst) {
        lst.forEach(o -> System.out.println(o.toString()));
    }
}

