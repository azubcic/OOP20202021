package zd4;

import java.util.*;

public class App {

    public static void main(String[] args) {
        List<String[]> originalData = DataProcsng.readFromCsvFile("StudentInformation.csv");
        String[] colData;
        System.out.println("================ Original List ================\n"  + originalData.toString());
        colData = DataProcsng.getColumn(0, originalData);
        System.out.println("\nPrint out: ");
        for (String info : colData) {
            System.out.println(info);
        }
        Set<String> unique = DataProcsng.getUniques(colData);
        System.out.println("\n================ Uniques: ================");
        for (String string : unique) {
            System.out.println(string);
        }
        Map<String, List<String[]>> data = new HashMap<>();
        data = DataProcsng.returnAllUniques(unique, originalData, 0);
        System.out.println("\n================ Listing all data ================");
        DataProcsng.listData(data);
    }
}

