package zd4;

import java.io.*;
import java.util.*;

public class DataProcsng {

    public static List<String[]> readFromCsvFile(String fullPath) {
        List<String[]> data = new ArrayList<String[]>();
        File file = new File(fullPath);
        try (FileReader fr = new FileReader(file);
             BufferedReader br = new BufferedReader(fr);
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                data.add(line.split(", "));
            }
        } catch (FileNotFoundException e) {
            System.out.println("The file in " + fullPath + " does not exist!");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    public static String[] getColumn(int col, List<String[]> data) {
        String[] colData = new String[data.size() - 1];
        int counter = 0;
        for (String[] row : data) {
            if (data.indexOf(row) == 0) {
                continue;
            } else {
                colData[counter] = row[col];
                counter++;
            }
        }
        return colData;
    }

    public static Set<String> getUniques(String[] data) {
        Set<String> unique = new TreeSet<>();
        unique.addAll(Arrays.asList(data));
        return unique;
    }

    public static Map<String, List<String[]>> returnAllUniques(Set<String> unique, List<String[]> rowData, int col) {
        Map<String, List<String[]>> allData = new TreeMap<>();
        List<String[]> subData;
        for (String key : unique) {
            subData = new ArrayList<>();
            for (String[] strings : rowData) {
                if (key.equals(strings[col])) {
                    subData.add(strings);
                } else {
                    continue;
                }
            }
            allData.put(key, subData);
        }
        return allData;
    }

    public static void listData(Map<String, List<String[]>> data) {
        for (String key : data.keySet()) {
            System.out.println("=> " + key + ": ");
            for (String[] subData : data.get(key)) {
                System.out.println(Arrays.toString(subData));
            }
            System.out.println("\n");
        }
    }
}
